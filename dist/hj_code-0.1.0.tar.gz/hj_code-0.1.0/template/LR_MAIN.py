# -*- coding: utf-8 -*-
"""
Created on Tue Aug 16 16:25:47 2022

@author: shrlin
"""

from functions.ExceptionDataProcess import *
from functions.DataCleaning import *

import pandas as pd


if __name__ == '__main__':
    data = pd.read_csv('mfd_bank_shibor.csv')




    
