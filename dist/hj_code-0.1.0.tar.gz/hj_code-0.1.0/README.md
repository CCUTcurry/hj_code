# hj_code
海捷数据分析通用化代码整理

## data：用于测试的数据
## functions：封装好的函数
## template：封装好的模板，内置的逻辑回归等完整流程
